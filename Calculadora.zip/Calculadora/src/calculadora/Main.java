package calculadora;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

	      System.out.println("Escolha uma das opções para calcular:");
	      System.out.println("[1] SOMA");
	      System.out.println("[2] SUBTRAÇÃO");
	      System.out.println("[3] MULTIPLICAÇÃO");
	      System.out.println("[4] DIVISÃO");

	      System.out.println("Digite o primeiro número decimal: ");
	      double opcao1 = scanner.nextDouble();

	      System.out.println("Digite o segundo decimal: ");
	      double opcao2 = scanner.nextDouble();

	      System.out.println("Digite a opção escolhida: ");
	      int escolha = scanner.nextInt();


	      double s = (double) opcao1 + opcao2;
	      double sub = (double) opcao1 - opcao2;
	      double m = (double) opcao1 * opcao2;
	      double d = (double) opcao1 / opcao2;

	      switch (escolha){
	        case 1:
	          System.out.println("A soma dos números é: " + s);
	          break;

	        case 2:
	          System.out.println("A subtração dos números é: " + sub);
	          break;

	        case 3:
	          System.out.printf("A multiplicação dos números é: %.2f%n", m);
	          break;

	        case 4:
	          System.out.printf("A divisão dos números é: %.2f%n", d);
	          break;

	        default:
	          System.out.println("Opção Inválida!");
	          break;
	           }
	      scanner.close();
	    }   



	}


